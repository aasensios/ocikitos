export class Breed {

    id: number;
    name: string;
    
  
    constructor(
        id?: number,
        name?: string,
    ) { }
  
  }