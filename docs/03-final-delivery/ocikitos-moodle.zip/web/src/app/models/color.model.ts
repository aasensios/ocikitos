export class Color {

  id: number;
  name: string;
  

  constructor(
      id?: number,
      name?: string,
  ) { }

}