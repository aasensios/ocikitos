import { DogDirective } from './dog.directive';

describe('DogDirective', () => {
  it('should create an instance', () => {
    const directive = new DogDirective();
    expect(directive).toBeTruthy();
  });
});
