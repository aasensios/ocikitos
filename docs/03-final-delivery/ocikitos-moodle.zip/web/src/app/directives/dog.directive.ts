import { Directive } from '@angular/core';

@Directive({
  selector: '[appDog]'
})
export class DogDirective {

  constructor() { }

}
