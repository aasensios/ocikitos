#!~anaconda3/envs/bio/bin/python

'''
Title          : multifasta_generator.py
Description    : Executable script to populate the database with fake DNA chunks,
                 hipotetically provided after the cuts by exonucleases and PCR amplification.
Authors        : Alejandro Asensio and Oscar Burgos
Date           : 2019-05-29
Script version : 1.3 -- Some variables refactored and usage of "with open()" file handling syntax.
Python version : 3.7.2
Usage          : $ python multifasta_generator.py
'''

import exrex
from random import randint
import random

files_number = 50

nucleotides = 'ACGT'

STRS = [
    ['FH2001', 23, 50961325, 50961475, 'GATA', 119, 160, 30, 40, 51],
    ['FH2004', 11, 32161381, 32161621, 'AAAG', 233, 325, 58, 81, 64],
    ['FH2010', 24, 5196383, 5196605, 'ATGA', 222, 243, 56, 61, 57],
    ['FH2054', 12, 37914504, 37914739, 'GATA', 139, 177, 35, 44, 57],
    ['FH2088', 15, 53905651, 53905779, 'TTTA/TTCA', 95, 138, 12, 17, 56],
    ['FH2107', 3, 83830247, 83830574, 'GAAA', 292, 426, 73, 107, 54],
    ['FH2309', 1, 85772974, 85773377, 'GAAA', 340, 428, 85, 107, 52],
    ['FH2328', 33, 19158127, 19158477, 'GAAA', 171, 213, 43, 53, 58],
    ['FH3377', 3, 78748898, 78749090, 'GAAAA', 184, 305, 37, 61, 54],
    ['PEZ02', 17, 13276076, 13276209, 'GGAA', 104, 144, 26, 36, 60],
    ['PEZ05', 12, 60326434, 60326541, 'TTTA', 92, 116, 23, 29, 57],
    ['PEZ16', 27, 10305692, 10305995, 'GAAA', 281, 332, 70, 83, 57],
    ['PEZ17', 4, 71904833, 71905038, 'GAAA', 191, 225, 48, 56, 59],
    ['PEZ21', 2, 36438658, 36438751, 'AAAT', 83, 103, 21, 26, 52],
    ['VWF.X', 27, 41977918, 41978074, 'AGGAAT', 151, 187, 25, 31, 57],
]

# Generate all the multifasta files
for y in range(files_number):

    # Generate one single multifasta content
    seq_final = ''
    for STR in STRS:
        head = f'>{STR[0]} Locus STR Canis lupus familiaris Chromosome {STR[1]} {STR[2]} {STR[3]}'

        repeat_motif = STR[4]
        min_rep = STR[7]
        max_rep = STR[8]
        regex = '('+repeat_motif+')'+'{'+str(min_rep)+','+str(max_rep)+'}'

        upstream = ''
        repeats_region = exrex.getone(regex)
        downstream = ''
        seq_loci = ''

        upstream_length = randint(15, 35)
        downstream_length = randint(15, 35)

        for x1 in range(upstream_length):
            upstream = upstream + random.choice(nucleotides)

        for x2 in range(downstream_length):
            downstream = downstream + random.choice(nucleotides)

        seq_loci = upstream + repeats_region + downstream

        seq_final = seq_final + head + '\n' + seq_loci + '\n'

    # FASTA file creation
    path = '../fasta/'
    filename = f'sample_{y + 1}'
    extension = '.fasta'
    file = path + filename + extension

    with open(file, 'w') as fasta_file:
        fasta_file.write(seq_final)

# Output message
print(f'{y + 1} FASTA files generated successfully.')
