#!~anaconda3/envs/bio/bin/python

'''
Title          : str_matching.py
Description    : Executable script called by PHP language after adding a new
                 multifasta file into an existing sample register.
Authors        : Alejandro Asensio and Oscar Burgos
Date           : 2019-05-29
Script version : 1.0
Python version : 3.7.2
Usage          : $ python str_matching.py
                 --multifasta ../fasta/sample_1.fasta
'''

import os
import click
import re

import utilslib

STRS = [
    ['FH2001', 23, 50961325, 50961475, 'GATA', 119, 160, 30, 40, 51],
    ['FH2004', 11, 32161381, 32161621, 'AAAG', 233, 325, 58, 81, 64],
    ['FH2010', 24, 5196383, 5196605, 'ATGA', 222, 243, 56, 61, 57],
    ['FH2054', 12, 37914504, 37914739, 'GATA', 139, 177, 35, 44, 57],
    ['FH2088', 15, 53905651, 53905779, 'TTTA/TTCA', 95, 138, 12, 17, 56],
    ['FH2107', 3, 83830247, 83830574, 'GAAA', 292, 426, 73, 107, 54],
    ['FH2309', 1, 85772974, 85773377, 'GAAA', 340, 428, 85, 107, 52],
    ['FH2328', 33, 19158127, 19158477, 'GAAA', 171, 213, 43, 53, 58],
    ['FH3377', 3, 78748898, 78749090, 'GAAAA', 184, 305, 37, 61, 54],
    ['PEZ02', 17, 13276076, 13276209, 'GGAA', 104, 144, 26, 36, 60],
    ['PEZ05', 12, 60326434, 60326541, 'TTTA', 92, 116, 23, 29, 57],
    ['PEZ16', 27, 10305692, 10305995, 'GAAA', 281, 332, 70, 83, 57],
    ['PEZ17', 4, 71904833, 71905038, 'GAAA', 191, 225, 48, 56, 59],
    ['PEZ21', 2, 36438658, 36438751, 'AAAT', 83, 103, 21, 26, 52],
    ['VWF.X', 27, 41977918, 41978074, 'AGGAAT', 151, 187, 25, 31, 57],
]

match = False
sequenced_sample_id = ''
found_sample_id = ''

# ----------------------------------------------------------------------
@click.command()
@click.option('--multifasta', prompt='multifasta file')
def main(multifasta: str):
    '''Reads multifasta and searches for a potential match among sample
    patterns stored in database.
    - It uses Click library decorator to parse the command line.
    - It uses custom regex to find a potential match.
    '''

    # Read the multifasta file.
    # TODO: Check why the output is string (list expected)
    sequences_list = utilslib.read_file(multifasta)

    # Generate a dict using dictionary comprehension.
    motifs_list = {STR[0]: STR[4] for STR in STRS}

    # Generate an empty dict to store the motifs repeats.
    motifs_repeats = {}

    # Loop through to count the repeats.
    for locus, motif in motifs_list.items():
        regex = motif
        pattern = re.compile(regex)
        matches = pattern.findall(sequences_list)
        repeats = len(matches)
        motifs_repeats[locus] = repeats

    # TODO: continue...
    motifs_repeats
    # ...


# ----------------------------------------------------------------------
# if __name__ == '__main__':
    # Method 1: Call the main function with arguments
    # main('genbank/insulin-homo-sapiens.gbff', 'out.txt', 10)

    # THIS ONE IS OK --> Method 2: Call the decorated main function without arguments
    # main()


# ----------------------------------------------------------------------
# Output message
if (match):
    print(f"Horray! There's a match between recently sequenced sample \
        {sequenced_sample_id} and stored {found_sample_id}.")
else:
    print(f"Well... No matches have been found in database.")
